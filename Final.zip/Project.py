# 20221123 천사은
# Images from : (Background) https://opengameart.org/content/cave-tileset-0
#               (Player) https://lyaseek.itch.io/miniffanimals
#               (Elements) https://dustdfg.itch.io/pixel-art-top-down-rocks-pack
#                          https://mokemo.itch.io/vegetable-icons-pack-part1
#                          https://artyomtop1gg.itch.io/garlic
# Sounds from : https://tiptoptomcat.itch.io/8-bit-gameboy-songs-vol-2-gb-studio


import pygame
import os
import time
import random
from os import path

file_dir = path.join(path.dirname(__file__), "assets")

WIDTH = 1000
HEIGHT = 700
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("20221123 천사은")
clock = pygame.time.Clock()


class Bear(pygame.sprite.Sprite):
    def __init__(self, speed):
        pygame.sprite.Sprite.__init__(self)
        self.frame = 0
        self.frame_rate = 5
        self.image = bear_images[self.frame]
        self.rect = self.image.get_rect()
        self.rect.topleft = (WIDTH // 2, HEIGHT // 2)
        self.speed = speed
        self.direction = (1, 0)  # 초기 이동 방향 (우측)
        self.last_update = pygame.time.get_ticks()

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame = (self.frame + 1) % len(bear_images)
            if flip_toggle:  # 토글이 켜져 있을 때 이미지를 좌우반전하여 사용
                self.image = pygame.transform.flip(bear_images[self.frame], True, False)
            else:
                self.image = bear_images[self.frame]

        self.rect.x += self.direction[0] * self.speed
        self.rect.y += self.direction[1] * self.speed

        # 화면 밖으로 나가지 않도록 제한
        self.rect.x = max(80, min(self.rect.x, (WIDTH-110) - self.rect.width))
        self.rect.y = max(130, min(self.rect.y, (HEIGHT-45) - self.rect.height))


class Food(pygame.sprite.Sprite):
    def __init__(self, size):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(random.choice(food_image_file), (size, size))
        self.rect = self.image.get_rect()
        self.rect.topleft = (random.randrange(80, (WIDTH-110)),
                             random.randrange(130, (HEIGHT-45)))


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, size, bear_rect, food_rect, obstacles):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(random.choice(obstacle_image_file), (size, size))
        self.rect = self.image.get_rect()

        while True:
            self.rect.topleft = (random.randrange(80+size, (WIDTH-110-size)),
                                 random.randrange(130+size, (HEIGHT-45-size)))
           
            bear_collision = bear_rect.colliderect(self.rect)
            food_collision = food_rect.colliderect(self.rect)
            obstacles_collision = pygame.sprite.spritecollideany(self, obstacles)
            if not bear_collision and not food_collision and not obstacles_collision:
                break



def initialize_game():
    global score, stage, bear, food, obstacles, bear_move_interval, last_move_time
    global countdown_start_time, game_start_time, game_start, flip_toggle
    global title_music_playing, play_music_playing, ending_music_playing

    score = 0
    stage = 1
    bear = Bear(13)
    food = Food(40)
    obstacles = pygame.sprite.Group()
    bear_move_interval = 1.0 / bear.speed
    last_move_time = time.time()
    
    countdown_start_time = pygame.time.get_ticks()
    game_start_time = None
    game_start = False
    flip_toggle = False

    title_music_playing = False
    play_music_playing = False
    ending_music_playing = False
    title_music.stop()
    play_music.stop()
    ending_music.stop()


def show_title_screen():
    screen.fill(BLACK)
    title_font = pygame.font.Font(font, 100)
    title_text1 = title_font.render("Becoming", True, WHITE)
    title_text2 = title_font.render("Human", True, WHITE)
    start_font = pygame.font.Font(font, 30)
    start_text = start_font.render("Press any key to start", True, GREEN)
    screen.blit(title_text1, (WIDTH // 2 - title_text1.get_width() // 2, HEIGHT // 2 - 130))
    screen.blit(title_text2, (WIDTH // 2 - title_text2.get_width() // 2, HEIGHT // 2 - 30))
    screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2 + 170))
    pygame.display.flip()


def set_screen():
    screen.fill(WHITE)
    screen.blit(background, background_rect)
    screen.blit(bear.image, bear.rect)
    screen.blit(food.image, food.rect)
    obstacles.draw(screen)

    score_text = score_font.render(f'Score: {score}', True, WHITE)
    stage_text = stage_font.render(f'Day: {stage*10}', True, WHITE)
    screen.blit(score_text, (20, 20))
    screen.blit(stage_text, (20, 55))


def draw_countdown(screen, font, text, position):
    text_render = font.render(text, True, WHITE)
    text_rect = text_render.get_rect(center=position)
    screen.blit(text_render, text_rect)


def show_game_over():
    screen.blit(background, background_rect)
    screen.blit(bear.image, bear.rect)
    score_text = score_font.render(f'Score: {score}', True, WHITE)
    stage_text = stage_font.render(f'Day: {stage}', True, WHITE)
    screen.blit(score_text, (20, 20))
    screen.blit(stage_text, (20, 55))
    game_over_text = game_over_font.render('Game Over', True, RED)
    your_score_text = game_over_font.render(f'Your Score: {score}', True, RED)
    screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, 
                                 HEIGHT // 2 - game_over_text.get_height()))
    screen.blit(your_score_text, (WIDTH // 2 - your_score_text.get_width() // 2, 
                                  HEIGHT // 2 + your_score_text.get_height() // 2))
    pygame.display.flip()
    time.sleep(3)


def show_game_clear():
    screen.blit(background, background_rect)
    screen.blit(bear.image, bear.rect)
    score_text = score_font.render(f'Score: {score}', True, WHITE)
    stage_text = stage_font.render(f'Day: 100', True, WHITE)
    screen.blit(score_text, (20, 20))
    screen.blit(stage_text, (20, 55))
    game_clear_text = game_clear_font.render('Game Clear!', True, GREEN)
    your_score_text = game_clear_font.render(f'Your Score: {score}', True, GREEN)
    screen.blit(game_clear_text, (WIDTH // 2 - game_clear_text.get_width() // 2,
                                  HEIGHT // 2 - game_clear_text.get_height()))
    screen.blit(your_score_text, (WIDTH // 2 - your_score_text.get_width() // 2,
                                  HEIGHT // 2 + your_score_text.get_height() // 2))
    pygame.display.flip()
    time.sleep(6)



# 이미지 파일 불러오기
background = pygame.transform.scale(pygame.image.load(path.join(file_dir, "cave.png")), (WIDTH, HEIGHT))
background_rect = background.get_rect()

bear_images = []
for i in range(1, 7):
    filename = "moving{}.png".format(i)
    img = pygame.image.load(path.join(file_dir, filename)).convert_alpha()
    img = pygame.transform.scale(img, (108, 50))
    bear_images.append(img)

food_image_file = []
food_list = ["food1.png", "food2.png"]
for img in food_list:
     food_image_file.append(pygame.image.load(path.join(file_dir, img)).convert_alpha())

obstacle_image_file = []
obstacle_list = ["obstacle1.png", "obstacle2.png", "obstacle3.png", "obstacle4.png", "obstacle5.png", "obstacle6.png"]
for img in obstacle_list:
    obstacle_image_file.append(pygame.image.load(path.join(file_dir, img)).convert_alpha())


# 사운드 파일 불러오기
title_music = pygame.mixer.Sound(path.join(file_dir, 'Title.mp3'))
play_music = pygame.mixer.Sound(path.join(file_dir, 'Play.mp3'))
ending_music = pygame.mixer.Sound(path.join(file_dir, 'Ending.mp3'))

clear_sounds = []
for snd in ['Clear1.wav', 'Clear2.wav']:
    clear_sounds.append(pygame.mixer.Sound(path.join(file_dir, snd)))
game_over_sound = pygame.mixer.Sound(path.join(file_dir, 'Gameover.wav'))

title_music.set_volume(0.5)
play_music.set_volume(0.3)
ending_music.set_volume(0.3)
clear_sounds[0].set_volume(1)
clear_sounds[1].set_volume(1)
game_over_sound.set_volume(1)


# 폰트 설정
font = path.join(file_dir, "slkscrb.ttf")
score_font = pygame.font.Font(font, 30)
stage_font = pygame.font.Font(font, 30)
countdown_font = pygame.font.Font(font, 50)
game_clear_font = pygame.font.Font(font, 50)
game_over_font = pygame.font.Font(font, 50)



initialize_game()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN: # 키보드 입력 시 게임 실행
            if game_start == False:
                game_start = True
                game_start_time = pygame.time.get_ticks()

            # 키보드로 플레이어 방향 조작
            if event.key == pygame.K_UP or event.key == pygame.K_w:
                bear.direction = (0, -1)
            elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                bear.direction = (0, 1)
            elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                bear.direction = (-1, 0)
                flip_toggle = True
            elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                bear.direction = (1, 0)
                flip_toggle = False

    # 타이틀 화면 표시
    if game_start == False:
        if not title_music_playing:
            title_music.play(-1)
            title_music_playing = True
        show_title_screen()
        pygame.display.flip()
        continue

    # 3초 카운트다운
    elif game_start_time is not None:
        if not play_music_playing:
            title_music.stop()
            play_music.play(-1)
            play_music_playing = True
        elapsed_time = pygame.time.get_ticks() - game_start_time
        if elapsed_time < 3000:
            countdown_number = 3 - int(elapsed_time / 1000)
            set_screen()
            draw_countdown(screen, countdown_font, str(countdown_number), (WIDTH // 2, HEIGHT // 2))
            pygame.display.flip()
            pygame.time.delay(1000)
            pygame.event.pump()
            continue

    current_time = time.time()
    if current_time - last_move_time > bear_move_interval:
        last_move_time = current_time

        bear.update()
        obstacles.update()

        # Obstacle과 충돌 시 게임오버 후 메인화면으로 돌아감
        collisions = pygame.sprite.spritecollide(bear, obstacles, False)
        if collisions:
            play_music.stop()
            game_over_sound.play()
            show_game_over()
            initialize_game()            

        # Food와 충돌 시 점수/스테이지 증가
        if bear.rect.colliderect(food.rect):
            random.choice(clear_sounds).play()
            score += 247
            stage += 1
            obstacles.empty()
            for i in range(stage):
                obstacle = Obstacle(65, bear.rect, food.rect, obstacles)
                obstacles.add(obstacle)
            food = Food(50)
                    
    # 모든 스테이지 완료시 게임 클리어 후 메인화면으로 돌아감
    if stage > 10:
        if not ending_music_playing:
            play_music.stop()
            ending_music.play()
            ending_music_playing = True
        show_game_clear()
        initialize_game()

    set_screen()
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
# 20221123 천사은
# Images from : (Background) https://opengameart.org/content/cave-tileset-0
#               (Player) https://lyaseek.itch.io/miniffanimals
#               (Elements) https://dustdfg.itch.io/pixel-art-top-down-rocks-pack
#                          https://mokemo.itch.io/vegetable-icons-pack-part1
#                          https://artyomtop1gg.itch.io/garlic

import pygame
import os
import time
import random

from os import path
file_dir = path.join(path.dirname(__file__), 'assets')

WIDTH = 1000
HEIGHT = 700
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

background = pygame.transform.scale(pygame.image.load(os.path.join(file_dir, "cave.png")), (WIDTH, HEIGHT))
background_rect = background.get_rect()

class Bear(pygame.sprite.Sprite):
    def __init__(self, width, height, speed):
        pygame.sprite.Sprite.__init__(self)

        # 캐릭터 애니메이션 이미지 리스트 초기화
        self.animation_images = []
        for i in range(1, 7):
            filename = f"moving{i}.png"
            img = pygame.image.load(os.path.join(file_dir, filename)).convert()
            img.set_colorkey(BLACK)
            img = pygame.transform.scale(img, (width, height))
            self.animation_images.append(img)

        # 현재 애니메이션 프레임 및 프레임 간격 설정
        self.frame = 0
        self.frame_rate = 5

        # 캐릭터 초기 이미지 설정
        self.image = self.animation_images[self.frame]
        self.rect = self.image.get_rect()
        self.rect.topleft = (WIDTH // 2, HEIGHT // 2)
        self.speed = speed
        self.direction = (1, 0)  # 초기 이동 방향 (우측)
        self.last_update = pygame.time.get_ticks()

    def update(self):
        now = pygame.time.get_ticks()

        # 일정 간격마다 애니메이션 업데이트
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame = (self.frame + 1) % len(self.animation_images)
            self.image = self.animation_images[self.frame]

        self.rect.x += self.direction[0] * self.speed
        self.rect.y += self.direction[1] * self.speed

        # 화면 밖으로 나가지 않도록 제한
        self.rect.x = max(80, min(self.rect.x, (WIDTH-110) - self.rect.width))
        self.rect.y = max(130, min(self.rect.y, (HEIGHT-45) - self.rect.height))


class Food(pygame.sprite.Sprite):
    def __init__(self, size):
        pygame.sprite.Sprite.__init__(self)
        food_image_file = random.choice(["food1.png", "food2.png"])
        self.image = pygame.transform.scale(pygame.image.load(os.path.join(file_dir, food_image_file)), (size, size))
        self.rect = self.image.get_rect()
        self.rect.topleft = (random.randrange(80, (WIDTH-110)),
                             random.randrange(130, (HEIGHT-45)))


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, size, bear_rect, food_rect, obstacles):
        pygame.sprite.Sprite.__init__(self)
        obstacle_image_file = random.choice(["obstacle1.png", "obstacle2.png", "obstacle3.png", "obstacle4.png", "obstacle5.png", "obstacle6.png"])
        self.image = pygame.transform.scale(pygame.image.load(os.path.join(file_dir, obstacle_image_file)), (size, size))
        self.rect = self.image.get_rect()
        while True:
            self.rect.topleft = (random.randrange(80, (WIDTH-110-size)),
                                 random.randrange(130, (HEIGHT-45-size)))
            # Bear와의 충돌 검사
            if not bear_rect.colliderect(self.rect):
                # Food와의 충돌 검사
                if not food_rect.colliderect(self.rect):
                    # Obstacle 객체 간의 충돌 검사
                    if not pygame.sprite.spritecollideany(self, obstacles):
                        break


def draw_countdown_text(screen, font, text, position):
    text_render = font.render(text, True, WHITE)
    text_rect = text_render.get_rect(center=position)
    screen.blit(text_render, text_rect)


def main():
    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('20221123 천사은')
    clock = pygame.time.Clock()

    score = 0
    stage = 1

    bear = Bear(97, 45, 12)
    obstacles = pygame.sprite.Group()
    food = Food(40)

    font_name = "slkscrb.ttf"
    # 각 텍스트에 대해 다른 크기의 폰트 객체 생성
    score_font = pygame.font.Font(font_name, 30)
    stage_font = pygame.font.Font(font_name, 30)
    countdown_font = pygame.font.Font(font_name, 50)
    game_clear_font = pygame.font.Font(font_name, 50)
    game_over_font = pygame.font.Font(font_name, 50)

    bear_move_interval = 1.0 / bear.speed
    last_move_time = time.time()

    # 3초 카운트다운
    countdown_start_time = pygame.time.get_ticks()
    countdown_duration = 3000  # milliseconds

    running = True
    while running:
        # 이벤트 처리
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP or event.key == pygame.K_w:
                    bear.direction = (0, -1)  # 위쪽으로 이동
                elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    bear.direction = (0, 1)  # 아래쪽으로 이동
                elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    bear.direction = (-1, 0)  # 왼쪽으로 이동
                elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    bear.direction = (1, 0)  # 오른쪽으로 이동

        # 3초 카운트다운 텍스트 표시
        elapsed_time = pygame.time.get_ticks() - countdown_start_time
        if elapsed_time < countdown_duration:
            countdown_number = 3 - int(elapsed_time / 1000)
            screen.fill(WHITE)
            screen.blit(background, background_rect)
            screen.blit(food.image, food.rect)
            screen.blit(bear.image, bear.rect)
            obstacles.draw(screen)
            score_text = score_font.render(f'Score: {score}', True, WHITE)
            stage_text = stage_font.render(f'Day: {stage*10}', True, WHITE)
            screen.blit(score_text, (10, 10))
            screen.blit(stage_text, (10, 40))
            draw_countdown_text(screen, countdown_font, str(countdown_number), (WIDTH // 2, HEIGHT // 2))
            pygame.display.flip()
            pygame.time.delay(1000)  # 1초 대기
            pygame.event.pump()
            continue


        current_time = time.time()
        if current_time - last_move_time > bear_move_interval:
            last_move_time = current_time

            bear.update()

            obstacles.update()
            collisions = pygame.sprite.spritecollide(bear, obstacles, False)
            if collisions:
                running = False

            if bear.rect.colliderect(food.rect):
                score += 10
                stage += 1
                obstacles.empty()

                for i in range(stage):
                    # Obstacle 생성 시 bear.rect 전달
                    obstacle = Obstacle(65, bear.rect, food.rect, obstacles)
                    obstacles.add(obstacle)
                food = Food(50)
                        
        if stage > 10:
            # Stage가 10을 넘으면 Game Clear! 메시지를 표시하고 게임 종료
            game_clear_text = game_clear_font.render('Game Clear!', True, GREEN)
            screen.blit(game_clear_text, (WIDTH // 2 - game_clear_text.get_width() // 2, HEIGHT // 2))
            pygame.display.flip()
            time.sleep(3)
            pygame.quit()

        screen.fill(WHITE)
        screen.blit(background, background_rect)
        screen.blit(food.image, food.rect)
        screen.blit(bear.image, bear.rect)
        obstacles.draw(screen)

        score_text = score_font.render(f'Score: {score}', True, WHITE)
        stage_text = stage_font.render(f'Day: {stage*10}', True, WHITE)
        screen.blit(score_text, (10, 10))
        screen.blit(stage_text, (10, 40))

        pygame.display.flip()
        clock.tick(FPS)

    # 게임 종료 화면
    game_over_text_line1 = game_over_font.render('Game Over', True, RED)
    game_over_text_line2 = game_over_font.render(f'Your Score: {score}', True, RED)
    screen.blit(game_over_text_line1, (WIDTH // 2 - game_over_text_line1.get_width() // 2, 
                                       HEIGHT // 2 - game_over_text_line1.get_height()))
    screen.blit(game_over_text_line2, (WIDTH // 2 - game_over_text_line2.get_width() // 2, 
                                       HEIGHT // 2 + game_over_text_line2.get_height() // 2))
    pygame.display.flip()
    time.sleep(3)

    pygame.quit()


if __name__ == "__main__":
    main()
